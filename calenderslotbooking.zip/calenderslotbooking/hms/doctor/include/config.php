<?php
$mysql_hostname = "localhost";
$mysql_user = "adil";
$mysql_password = "123456";
$mysql_database = "hms";
$bd = mysqli_connect()($mysql_hostname, $mysql_user, $mysql_password) or die("Could not connect database");
mysql_select_db($mysql_database, $bd) or die("Could not select database");

?>